/* Fork of Artefact2/libxm for Windows 9x and higher              */
/* Fork maintainer: MikeEviscerate <cpe.bach03@proton.me>         */

/* libxm author: Romain "Artefact2" Dalmaso <artefact2@gmail.com> */
/* libxm contributor: Daniel Oaks <daniel@danieloaks.net> */

/* This program is free software. It comes without any warranty, to the
 * extent permitted by applicable law. You can redistribute it and/or
 * modify it under the terms of the Do What The Fuck You Want To Public
 * License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

#include "xm_internal.h"
#define _XM_FILE_NAME play_c

#include <stdlib.h>



/* ----- Static functions ----- */

static int8_t xm_waveform(uint8_t, uint8_t);

#if HAS_FEATURE(FEATURE_AUTOVIBRATO)
static void xm_autovibrato(xm_channel_context_t*);
#endif

#if HAS_VIBRATO
static bool xm_slot_has_vibrato(const xm_pattern_slot_t*);
static void xm_vibrato(xm_channel_context_t*);
#endif

#if HAS_EFFECT(EFFECT_TREMOLO) || HAS_EFFECT(EFFECT_S3M_TREMOLO)
static void xm_tremolo(xm_channel_context_t*, uint8_t);
#endif

#if HAS_EFFECT(EFFECT_TREMOR) || HAS_EFFECT(EFFECT_S3M_TREMOR)
static void xm_tremor(xm_channel_context_t*, uint8_t);
#endif

#if HAS_EFFECT(EFFECT_MULTI_RETRIG_NOTE) \
    || HAS_EFFECT(EFFECT_S3M_MULTI_RETRIG_NOTE)
static void xm_multi_retrig_note(xm_context_t*, xm_channel_context_t*, uint8_t);
#endif

#if HAS_ARPEGGIO
static void xm_arpeggio(const xm_context_t*, xm_channel_context_t*, uint8_t);
#endif

#if HAS_TONE_PORTAMENTO
static bool xm_slot_has_tone_portamento(const xm_pattern_slot_t*);
static void xm_tone_portamento(const xm_context_t*, xm_channel_context_t*);
static void xm_tone_portamento_target(const xm_context_t*, xm_channel_context_t*);
#endif

#if HAS_GLOBAL_EFFECT_MEMORY
static void xm_volume_slide_s3m(xm_channel_context_t*);
#endif

enum _xm_pitch_slide_behaviour_enum { PITCH_SLIDE_WRAPAROUND, PITCH_SLIDE_CLAMP, PITCH_SLIDE_CUT };
typedef uint8_t xm_pitch_slide_behaviour_t;
static void xm_pitch_slide(xm_channel_context_t*, int16_t, xm_pitch_slide_behaviour_t);
static void xm_param_slide(uint8_t*, uint8_t, uint8_t);
static void xm_tick_effects(xm_context_t*, xm_channel_context_t*);

static uint8_t xm_envelope_lerp(const xm_envelope_point_t* RESTRICT, const xm_envelope_point_t* RESTRICT, uint16_t);
static uint8_t xm_tick_envelope(xm_channel_context_t*, const xm_envelope_t*, uint16_t*);

static void xm_tick_envelopes(xm_channel_context_t*);

static uint16_t xm_linear_period(int16_t);
static uint16_t xm_amiga_period(int16_t);
static uint16_t xm_period(const xm_context_t*, int16_t) ;

static uint32_t xm_linear_frequency(uint16_t, uint8_t);
static uint32_t xm_amiga_frequency(uint16_t, uint8_t);
static uint32_t xm_frequency(const xm_context_t*, const xm_channel_context_t*) ;

#if HAS_GLISSANDO_CONTROL
static void xm_round_linear_period_to_semitone(xm_channel_context_t*);
static void xm_round_amiga_period_to_semitone(xm_channel_context_t*);
static void xm_round_period_to_semitone(const xm_context_t*, xm_channel_context_t*);
#endif

static void xm_handle_pattern_slot(xm_context_t*, xm_channel_context_t*);
static void xm_trigger_instrument(xm_context_t*, xm_channel_context_t*);
static void xm_trigger_note(xm_context_t*, xm_channel_context_t*);
static void xm_cut_note(xm_channel_context_t*);
static void xm_key_off(xm_channel_context_t*);

static void xm_row(xm_context_t*);

static float xm_sample_at(const xm_context_t*, const xm_sample_t*, uint32_t);
static float xm_next_of_sample(xm_context_t*, xm_channel_context_t*);
static void xm_next_of_channel(xm_context_t*, xm_channel_context_t*, float*, float*);
static void xm_sample_unmixed(xm_context_t*, float*);
static void xm_sample(xm_context_t*, float*, float*);

/* ----- Other oddities ----- */

#define XM_CLAMP_UP1F(vol, limit) do {                                  \
        if((vol) > (limit)) (vol) = (limit); \
    } while(0)
#define XM_CLAMP_UP(vol) XM_CLAMP_UP1F((vol), 1.f)

#define XM_CLAMP_DOWN1F(vol, limit) do {                                \
        if((vol) < (limit)) (vol) = (limit); \
    } while(0)
#define XM_CLAMP_DOWN(vol) XM_CLAMP_DOWN1F((vol), .0f)

#define XM_CLAMP2F(vol, up, down) do {                                  \
        if((vol) > (up)) (vol) = (up); \
        else if((vol) < (down)) (vol) = (down); \
    } while(0)
#define XM_CLAMP(vol) XM_CLAMP2F((vol), 1.f, .0f)

#define XM_LERP(u, v, t) ((u) + (t) * ((v) - (u)))

#if XM_RAMPING
    static INLINE void XM_SLIDE_TOWARDS(float* val, float goal, float incr) {
        if(*val > goal) {
            *val -= incr;
            XM_CLAMP_DOWN1F(*val, goal);
        } else {
            *val += incr;
            XM_CLAMP_UP1F(*val, goal);
        }
    }
#endif


static bool NOTE_IS_KEY_OFF(uint8_t n) {
    _XM_STATIC_ASSERT_FUNCTION(NOTE_KEY_OFF == 128,"");
    _XM_STATIC_ASSERT_FUNCTION(MAX_NOTE < 128,"");
    _XM_STATIC_ASSERT_FUNCTION(NOTE_RETRIGGER < 128,"");
    _XM_STATIC_ASSERT_FUNCTION(NOTE_SWITCH < 128,"");

    #if HAS_FEATURE(FEATURE_NOTE_KEY_OFF)
    return n & 128;
    #else
    return false;
    #endif
}


static void UPDATE_EFFECT_MEMORY_XY(uint8_t* memory, uint8_t value) {
    if(value & 0x0F) {
        *memory = (*memory & 0xF0) | (value & 0x0F);
    }
    if(value & 0xF0) {
        *memory = (*memory & 0x0F) | (value & 0xF0);
    }
}

/* ----- Function definitions ----- */

static int8_t xm_waveform(uint8_t waveform,
                          uint8_t step) {

    #if HAS_FEATURE(FEATURE_WAVEFORM_SINE)
    #endif
    #if HAS_FEATURE(FEATURE_WAVEFORM_RANDOM)
        static uint32_t state = 0;
    #endif

    #if !HAS_FEATURE(FEATURE_WAVEFORM_SINE) \
        && !HAS_FEATURE(FEATURE_WAVEFORM_SQUARE) \
        && !HAS_FEATURE(FEATURE_WAVEFORM_RAMP_DOWN) \
        && !HAS_FEATURE(FEATURE_WAVEFORM_RAMP_UP) \
        && !HAS_FEATURE(FEATURE_WAVEFORM_RANDOM)
    return 0;
    #endif

    #if HAS_FEATURE(FEATURE_WAVEFORM_CONTINUE)
    waveform &= 127;
    #endif

    switch(waveform) {

    /* In case some waveforms were compiled out, default to the first
       enabled waveform */
    default:
        ;
    #if HAS_FEATURE(FEATURE_WAVEFORM_SINE)
    case WAVEFORM_SINE:
        step >>= 2;
        {
            static const int8_t sin_lut[] = {
                /* 128*sinf(2?x/64) for x in 0..16 */
                0, 12, 24, 37, 48, 60, 71, 81,
                90, 98, 106, 112, 118, 122, 125, 127,
            };
            uint8_t idx;
            idx = step & 0x10 ? 0xF - (step & 0xF) : (step & 0xF);
            return (int8_t)((step < 0x20) ? -sin_lut[idx] : sin_lut[idx]);
        }
    #endif

    #if HAS_FEATURE(FEATURE_WAVEFORM_SQUARE)
    case WAVEFORM_SQUARE:
        return (step < 0x80) ? INT8_MIN : INT8_MAX;
    #endif

    #if HAS_FEATURE(FEATURE_WAVEFORM_RAMP_DOWN)
    case WAVEFORM_RAMP_DOWN:
        /* Starts at zero, wraps around at the middle */
        return (int8_t)(-step - 1);
    #endif

    #if HAS_FEATURE(FEATURE_WAVEFORM_RAMP_UP)
    case WAVEFORM_RAMP_UP:
        /* Only used by autovibrato, regular E4y/E7y will use a square
           wave instead (this is set by load.c) */
        return (int8_t)step;
    #endif

    #if HAS_FEATURE(FEATURE_WAVEFORM_RANDOM)
    case WAVEFORM_RANDOM:
        /* XXX: make me reentrant */
        {
            static uint32_t state = 0;
        }
        return (int8_t)xm_rand16(&state);
    #endif

    }

    assert(0);
}


#if HAS_FEATURE(FEATURE_AUTOVIBRATO)
static void xm_autovibrato(xm_channel_context_t* ch) {
    xm_instrument_t* instr = ch->instrument;
    if(instr == NULL) return;

    /* Autovibrato speed is 4x slower than equivalent 4xx effect (ie,
       autovibrato_rate of 4 is the same as 41y). */
    /* Autovibrato depth is 8x smaller than equivalent 4xx effect (ie,
       autovibrato_depth of 8 is the same as 4x1). */
    /* Autovibrato also flips the sign of the waveform. */
    /* Autovibrato is cumulative with regular vibrato and is also a straight
       period offset for amiga frequencies. */

    /* Depth 16 = 0.5 semitone amplitude (-0.25 then +0.25) */
    /* Scale waveform from -128..127 to -16..15 at depth 16 */
    ch->autovibrato_offset = (int8_t)
        (((int16_t)xm_waveform(instr->vibrato_type,
                               (uint8_t)(ch->autovibrato_ticks
                                         * instr->vibrato_rate)))
         * (-instr->vibrato_depth) / 128);

    if(ch->autovibrato_ticks < instr->vibrato_sweep) {
        ch->autovibrato_offset = (int8_t)
            ((int16_t)ch->autovibrato_offset
            * ch->autovibrato_ticks / instr->vibrato_sweep);
    }

    ch->autovibrato_ticks++;
}
#endif

#if HAS_VIBRATO
static void xm_vibrato(xm_channel_context_t* ch) {
    uint8_t div;
    
    /* Reset glissando control error */
    xm_pitch_slide(ch, 0, 0);

    /* Regular vibrato: depth 8 == 2 semitones amplitude (-1 then +1) */
    /* Fine vibrato: depth 8 == 0.5 semitone amplitude */
    div = (HAS_EFFECT(EFFECT_VIBRATO)
                   && HAS_EFFECT(EFFECT_FINE_VIBRATO))
        ? ((ch->current->effect_type == EFFECT_FINE_VIBRATO)
           ? 0x40 : 0x10)
        : (HAS_EFFECT(EFFECT_VIBRATO) ? 0x10 : 0x40);
    ch->vibrato_offset = (int8_t)
        ((int16_t)xm_waveform(VIBRATO_CONTROL_PARAM(ch),
                              ch->vibrato_ticks)
         * (ch->vibrato_param & 0x0F) / div);
    ch->vibrato_ticks += (uint8_t)((ch->vibrato_param >> 4) << 2);
}

static bool xm_slot_has_vibrato(const xm_pattern_slot_t* s) {
    return (HAS_EFFECT(EFFECT_VIBRATO) && s->effect_type == EFFECT_VIBRATO)
        || (HAS_EFFECT(EFFECT_FINE_VIBRATO)
            && s->effect_type == EFFECT_FINE_VIBRATO)
        || (HAS_EFFECT(EFFECT_VIBRATO_VOLUME_SLIDE)
            &&s->effect_type == EFFECT_VIBRATO_VOLUME_SLIDE)
        || (HAS_EFFECT(EFFECT_S3M_VIBRATO_VOLUME_SLIDE)
            &&s->effect_type == EFFECT_S3M_VIBRATO_VOLUME_SLIDE)
        || (HAS_VOLUME_EFFECT(VOLUME_EFFECT_VIBRATO)
            && (VOLUME_COLUMN(s) >> 4) == VOLUME_EFFECT_VIBRATO);
}
#endif

#if HAS_EFFECT(EFFECT_TREMOLO) || HAS_EFFECT(EFFECT_S3M_TREMOLO)
static void xm_tremolo(xm_channel_context_t* ch, uint8_t param) {
    /* Additive volume effect based on a waveform. Depth 8 is plus or minus
       32 volume. Works in the opposite direction of vibrato (ie, ramp down
       means pitch goes down with vibrato, but volume goes up with
       tremolo.). Tremolo, like vibrato, is not applied on 1st tick of every
       row (has no effect on Spd=1). */
    /* Like Txy: Tremor, tremolo effect *persists* after the end of the
       effect, but is reset after any volume command. */

    uint8_t ticks = ch->tremolo_ticks;
    if(HAS_FEATURE(FEATURE_WAVEFORM_RAMP_DOWN)
       && (TREMOLO_CONTROL_PARAM(ch) & 127) == WAVEFORM_RAMP_DOWN) {
        /* FT2 quirk, ramp waveform with tremolo is weird and is also
           influenced by vibrato ticks... */
        if(ticks >= 0x80) {
            ticks = 0x80 - ticks;
        }
        #if HAS_VIBRATO
        if(ch->vibrato_ticks >= 0x80) {
            ticks = 0x80 - ticks;
        }
        #endif
    }
    ch->volume_offset = (int8_t)
        ((int16_t)xm_waveform(TREMOLO_CONTROL_PARAM(ch), ticks)
        * (param & 0x0F) * 4 / 128);
    ch->tremolo_ticks += (uint8_t)((param >> 4) << 2);
}
#endif

#if HAS_EFFECT(EFFECT_TREMOR) || HAS_EFFECT(EFFECT_S3M_TREMOR)
static void xm_tremor(xm_channel_context_t* ch, uint8_t param) {
    /* (x+1) ticks on, then (y+1) ticks off */
    /* Effect is not the same every row: it keeps an internal tick
       counter and updates to the parameter only matters at the end
       of an on or off cycle */
    /* If tremor ends with "off" volume, volume stays off, but *any*
       volume effect restores the volume (with the volume effect
       applied). */
    /* It works exactly like 7xy: Tremolo with a square waveform,
       and xy param defines the period and duty cycle. */
    /* Tremor x and y params do not appear to be separately kept in
       memory, unlike Rxy */
    if(ch->tremor_ticks-- == 0) {
        ch->tremor_on = !ch->tremor_on;
        if(ch->tremor_on) {
            ch->tremor_ticks = param >> 4;
        } else {
            ch->tremor_ticks = param & 0xF;
        }
    }
    ch->volume_offset = ch->tremor_on ? 0 : MAX_VOLUME;
}
#endif

#if HAS_EFFECT(EFFECT_MULTI_RETRIG_NOTE) || HAS_EFFECT(EFFECT_S3M_MULTI_RETRIG_NOTE)
static void xm_multi_retrig_note(xm_context_t* ctx, xm_channel_context_t* ch, uint8_t param) {

    /* Seems to work similarly to Txy tremor effect. It uses an increasing
       counter and also runs on tick 0. */

    if(VOLUME_COLUMN(ch->current) && ctx->current_tick == 0) {
        /* ??? */
        return;
    }
    if(++ch->multi_retrig_ticks < (param & 0x0F)) {
        return;
    }
    ch->multi_retrig_ticks = 0;
    xm_trigger_note(ctx, ch);

    /* Fixed volume in volume column always has precedence */
    if((HAS_VOLUME_EFFECT(1) || HAS_VOLUME_EFFECT(2)
        || HAS_VOLUME_EFFECT(3) || HAS_VOLUME_EFFECT(4)
        || HAS_VOLUME_EFFECT(5))
       && VOLUME_COLUMN(ch->current) >= 0x10
       && VOLUME_COLUMN(ch->current) <= 0x50) {
        return;
    }

    {
        static const uint8_t add[] = {
            0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 4, 8, 16, 0, 0,
        };
        static const uint8_t mul[] = {
            1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 3, 2,
        };
        uint8_t x;

        x = (uint8_t)(param >> 4);
        ch->volume += add[x];
        ch->volume -= add[x ^ 8];
        ch->volume *= mul[x];
        ch->volume /= mul[x ^ 8];
    }

    _XM_STATIC_ASSERT_FUNCTION(MAX_VOLUME + 16 <= UINT8_MAX, "");
    _XM_STATIC_ASSERT_FUNCTION(MAX_VOLUME * 3 <= UINT8_MAX - 16, "");
    if(ch->volume > UINT8_MAX - 16) ch->volume = 0;
    else if(ch->volume > MAX_VOLUME) ch->volume = MAX_VOLUME;
}
#endif

#if HAS_ARPEGGIO
static void xm_arpeggio(const xm_context_t* ctx, xm_channel_context_t* ch, uint8_t param) {
    uint8_t t = CURRENT_TEMPO(ctx) - ctx->current_tick;

    if((HAS_EFFECT(EFFECT_DELAY_PATTERN) && ctx->current_tick == 0)
       || (HAS_FEATURE(FEATURE_ACCURATE_ARPEGGIO_OVERFLOW) && t == 16)
       || ((!HAS_FEATURE(FEATURE_ACCURATE_ARPEGGIO_OVERFLOW) || t < 16)
           && t % 3 == 0)) {
        ch->arp_note_offset = 0;
        return;
    }

    #if HAS_ARPEGGIO_RESET
    ch->should_reset_arpeggio = true;
    xm_round_period_to_semitone(ctx, ch);
    #endif

    if((HAS_FEATURE(FEATURE_ACCURATE_ARPEGGIO_OVERFLOW) && t > 16) || t % 3 == 2) {
        ch->arp_note_offset = param & 0x0F;
        return;
    }

    ch->arp_note_offset = param >> 4;
}
#endif

#if HAS_TONE_PORTAMENTO
static void xm_tone_portamento(const xm_context_t* ctx,
                               xm_channel_context_t* ch) {
    uint16_t incr;
    int32_t diff;
    /* 3xx called without a note, wait until we get an actual
     * target note. */
    if(ch->tone_portamento_target_period == 0 || ch->period == 0) return;

    incr = 4 * ch->tone_portamento_param;
    diff = ch->tone_portamento_target_period - ch->period;
    diff = diff > incr ? incr : diff;
    diff = diff < (-incr) ? (-incr) : diff;
    xm_pitch_slide(ch, (int16_t)diff, 0);

    #if HAS_GLISSANDO_CONTROL
    if(ch->glissando_control_param) {
        xm_round_period_to_semitone(ctx, ch);
    }
    #endif
}

static bool xm_slot_has_tone_portamento(const xm_pattern_slot_t* s) {
    return (HAS_EFFECT(EFFECT_TONE_PORTAMENTO)
            && s->effect_type == EFFECT_TONE_PORTAMENTO)
        || (HAS_EFFECT(EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE)
            && s->effect_type == EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE)
        || (HAS_EFFECT(EFFECT_S3M_TONE_PORTAMENTO_VOLUME_SLIDE)
            && s->effect_type == EFFECT_S3M_TONE_PORTAMENTO_VOLUME_SLIDE)
        || (HAS_VOLUME_EFFECT(VOLUME_EFFECT_TONE_PORTAMENTO)
            && (VOLUME_COLUMN(s) >> 4) == VOLUME_EFFECT_TONE_PORTAMENTO);
}

static void xm_tone_portamento_target(const xm_context_t* ctx,
                                      xm_channel_context_t* ch) {
    int16_t note;

    assert(xm_slot_has_tone_portamento(ch->current));
    if(ch->sample == NULL) return;

    /* Tone porta uses the relative note of whatever sample we have, even if
       the target note belongs to another sample with another relative
       note. */
    note = (int16_t)(ch->current->note + RELATIVE_NOTE(ch->sample));

    #if HAS_FEATURE(FEATURE_INVALID_NOTES)
    /* Invalid notes keep whatever target period was there before. */
    if(note <= 0 || note >= 120) return;
    #endif

    /* 3xx/Mx ignores E5y, but will reuse whatever finetune was set when
       initially triggering the note */
    /* XXX: refactor note+finetune logic with xm_trigger_note() */
    ch->tone_portamento_target_period = xm_period(ctx, (int16_t)(16 * (note - 1) + FINETUNE(ch)));
}
#endif

static void xm_pitch_slide(xm_channel_context_t* ch,
                           int16_t period_offset,
                           xm_pitch_slide_behaviour_t mode) {
    /* All pitch slides seem to reset the glissando error, and also cancel
       any lingering vibrato effect */
    #if HAS_GLISSANDO_CONTROL
    ch->period = (uint16_t)(ch->period + ch->glissando_control_error);
    ch->glissando_control_error = 0;
    #endif

    #if HAS_VIBRATO
    ch->vibrato_offset = 0;
    #endif

    switch(mode) {
    default:
        ch->period = (uint16_t)(ch->period + period_offset);
        break;

    #if HAS_FEATURE(FEATURE_ACCURATE_PITCH_SLIDE_CLAMP)
    case PITCH_SLIDE_CLAMP:
        if(_xm_ckd_add_u16_ui(&ch->period, ch->period, period_offset)) {
            ch->period = period_offset > 0 ? INT16_MAX : 1;
        }
        break;
    #endif

    #if HAS_FEATURE(FEATURE_ACCURATE_PITCH_SLIDE_CUT)
    case PITCH_SLIDE_CUT:
        if(_xm_ckd_add_u16_ui(&ch->period, ch->period, period_offset)) {
            ch->sample = NULL;
        }
        break;
    #endif
    }
}

static void xm_param_slide(uint8_t* param, uint8_t rawval, uint8_t max) {
    /* In FT2, sliding up has precendence for "illegal" slides, eg A1F. */
    if(rawval & 0xF0) {
        /* Slide up */
        if(_xm_ckd_add_u8_uu(param, *param, rawval >> 4) || *param > max) {
            *param = max;
        }
    } else {
        /* Slide down */
        if(_xm_ckd_sub_u8_uu(param, *param, rawval)) {
            *param = 0;
        }
    }
}

#if HAS_GLOBAL_EFFECT_MEMORY
static void xm_volume_slide_s3m(xm_channel_context_t* ch) {
    uint8_t p;
    uint8_t x = ch->effect_param >> 4;
    uint8_t y = ch->effect_param & 0xF;

    p = (x == 0 || y == 0)
        ? ch->effect_param /* Dx0, D0y, D0F, DF0 */
        : (y == 0xF
           ? (uint8_t)(x << 4) /* DxF, DFF */
           : y /* DFy, Dxy */);
    RESET_VOLUME_OFFSET(ch);
    xm_param_slide(&ch->volume, p, MAX_VOLUME);
}
#endif

static uint16_t xm_linear_period(int16_t note) {
    assert(7680 - note * 4 > 0);
    assert(7860 - note * 4 < UINT16_MAX);
    return (uint16_t)(7680 - note * 4);
}

static uint32_t xm_linear_frequency(uint16_t period, uint8_t arp_note_offset) {
    if(HAS_EFFECT(EFFECT_ARPEGGIO) && arp_note_offset) {
        /* XXX: test wraparound? */
        period -= (uint16_t)(arp_note_offset * 64);
        /* 1540 is the period of note 95+15/16ths, the maximum
           FT2 will use for an arpeggio */
        period = period < 1540 ? 1540 : period;
    }
    return (uint32_t)(8363.f * exp2f((4608.f - (float)period) / 768.f));
}

static uint16_t xm_amiga_period(int16_t note) {
    return (uint16_t)(32.f * 856.f * exp2f((float)note / (-12.f * 16.f)));
}

static uint32_t xm_amiga_frequency(uint16_t period, uint8_t arp_note_offset) {
    float p = (float)period;

    if(HAS_EFFECT(EFFECT_ARPEGGIO) && arp_note_offset) {
        p *= exp2f((float)arp_note_offset / (-12.f));
        p = p < 107.f ? 107.f : p;
    }

    /* This is the PAL value. No reason to choose this one over the
     * NTSC value. */
    return (uint32_t)(4.f * 7093789.2f / (p * 2.f));
}

static uint16_t xm_period(const xm_context_t* ctx, int16_t note) {
    return AMIGA_FREQUENCIES(&ctx->module)
        ? xm_amiga_period(note)
        : xm_linear_period(note);
}

static uint32_t xm_frequency(const xm_context_t* ctx, const xm_channel_context_t* ch) {
    uint16_t period;

    assert(ch->period > 0);
    /* XXX: test wraparound/overflow */
    period = (uint16_t)(ch->period - VIBRATO_OFFSET(ch) - AUTOVIBRATO_OFFSET(ch));

    return AMIGA_FREQUENCIES(&ctx->module)
        ? xm_amiga_frequency(period, ARP_NOTE_OFFSET(ch))
        : xm_linear_frequency(period, ARP_NOTE_OFFSET(ch));
}

#if HAS_GLISSANDO_CONTROL
static void xm_round_linear_period_to_semitone(xm_channel_context_t* ch) {
    /* With linear frequencies, 1 semitone is 64 period units and 16
       finetune units. */
    uint16_t new_period = (uint16_t) (((ch->period + FINETUNE(ch) * 4 + 32) & 0xFFC0) - FINETUNE(ch) * 4);

    ch->glissando_control_error = (int8_t)(ch->period - new_period);
    ch->period = new_period;
}

static void xm_round_amiga_period_to_semitone(xm_channel_context_t* ch) {
    /* XXX: todo */
}

/* Round period to nearest semitone. Store rounding error in
   ch->glissando_control_error. */
static void xm_round_period_to_semitone(const xm_context_t* ctx, xm_channel_context_t* ch) {
    /* Reset glissando control error */
    xm_pitch_slide(ch, 0, 0);

    if(AMIGA_FREQUENCIES(&ctx->module)) {
        xm_round_amiga_period_to_semitone(ch);
    } else {
        xm_round_linear_period_to_semitone(ch);
    }
}
#endif

static void xm_handle_pattern_slot(xm_context_t* ctx, xm_channel_context_t* ch) {
    xm_pattern_slot_t* s = ch->current;

    if(s->instrument) {
        /* Always update next_instrument, even with a key-off note. */
        ch->next_instrument = s->instrument;
    }

    if(!NOTE_IS_KEY_OFF(s->note)) {
        if(s->note) {
            if(s->note <= MAX_NOTE) {
                #if HAS_TONE_PORTAMENTO
                if(xm_slot_has_tone_portamento(ch->current)) {
                    /* Orig note (used for retriggers) is
                       not updated by tone portas */
                    xm_tone_portamento_target(ctx, ch);
                } else
                #endif
                {
                    ch->orig_note = s->note;
                    xm_trigger_note(ctx, ch);
                }
            } else {
                xm_trigger_note(ctx, ch);
            }
        }
    } else {
        xm_key_off(ch);
    }

    if(s->instrument) {
        if(ch->sample) {
            ch->volume = ch->sample->volume;
            #if HAS_PANNING
            ch->panning = PANNING(ch->sample);
            #endif
        }
        if(!NOTE_IS_KEY_OFF(s->note)) {
            xm_trigger_instrument(ctx, ch);
        }
    }

    /* These volume effects always work, even when called with a delay by
       EDy. */
    if((HAS_VOLUME_EFFECT(1) || HAS_VOLUME_EFFECT(2)
        || HAS_VOLUME_EFFECT(3) || HAS_VOLUME_EFFECT(4)
        || HAS_VOLUME_EFFECT(5))
       && VOLUME_COLUMN(s) >= 0x10 && VOLUME_COLUMN(s) <= 0x50) {
        /* Set volume */
        RESET_VOLUME_OFFSET(ch);
        ch->volume = (uint8_t)(VOLUME_COLUMN(s) - 0x10);
    }
    #if HAS_PANNING && HAS_VOLUME_EFFECT(VOLUME_EFFECT_SET_PANNING)
    if(VOLUME_COLUMN(s) >> 4 == VOLUME_EFFECT_SET_PANNING) {
        ch->panning = (uint8_t)(VOLUME_COLUMN(s) << 4);
    }
    #endif

    #if HAS_TONE_PORTAMENTO
    /* Set tone portamento memory (even on tick 0) */
    if(HAS_VOLUME_EFFECT(VOLUME_EFFECT_TONE_PORTAMENTO)
       && VOLUME_COLUMN(s) >> 4 == VOLUME_EFFECT_TONE_PORTAMENTO) {
        /* Mx *always* has precedence, even M0 */
        if(VOLUME_COLUMN(s) & 0x0F) {
            ch->tone_portamento_param = (uint8_t)(VOLUME_COLUMN(s) << 4);
        }
    } else if(HAS_EFFECT(EFFECT_TONE_PORTAMENTO) && s->effect_type == EFFECT_TONE_PORTAMENTO) {
        if(s->effect_param > 0) {
            ch->tone_portamento_param = s->effect_param;
        }
    }
    #endif

    #if HAS_GLOBAL_EFFECT_MEMORY
    if(s->effect_param) {
        /* XXX: test me better. Is it always set, or does it depend on
           the effect (eg only set on ticks 1+)? */
        ch->effect_param = s->effect_param;
    }
    #endif

    if(ctx->current_tick == 0) {
        /* These effects are ONLY applied at tick 0. If a note delay
           effect (EDy), where y>0, uses this effect in its volume
           column, it will be ignored. */

        #if HAS_VOLUME_COLUMN
        switch(VOLUME_COLUMN(s) >> 4) {

        #if HAS_VOLUME_EFFECT(VOLUME_EFFECT_FINE_SLIDE_DOWN)
        case VOLUME_EFFECT_FINE_SLIDE_DOWN:
            RESET_VOLUME_OFFSET(ch);
            xm_param_slide(&ch->volume, VOLUME_COLUMN(s) & 0x0F, MAX_VOLUME);
            break;
        #endif

        #if HAS_VOLUME_EFFECT(VOLUME_EFFECT_FINE_SLIDE_UP)
        case VOLUME_EFFECT_FINE_SLIDE_UP:
            RESET_VOLUME_OFFSET(ch);
            xm_param_slide(&ch->volume, (uint8_t)(VOLUME_COLUMN(s) << 4), MAX_VOLUME);
            break;
        #endif

        #if HAS_VOLUME_EFFECT(VOLUME_EFFECT_VIBRATO_SPEED)
        case VOLUME_EFFECT_VIBRATO_SPEED:
            /* XXX: test me (with note delay, with simultaneous
               4xy/40y) */
            /* S0 does nothing, but is deleted in load.c */
            UPDATE_EFFECT_MEMORY_XY(&ch->vibrato_param, (uint8_t)(VOLUME_COLUMN(s) << 4));
            break;
        #endif

        }
        #endif
    }

    switch(s->effect_type) {

    #if HAS_EFFECT(EFFECT_SET_VOLUME)
    case EFFECT_SET_VOLUME:
        RESET_VOLUME_OFFSET(ch);
        /* xx > MAX_VOLUME is already clamped in load.c */
        ch->volume = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_FINE_VOLUME_SLIDE_UP)
    case EFFECT_FINE_VOLUME_SLIDE_UP:
        if(s->effect_param) {
            ch->fine_volume_slide_up_param = (uint8_t)(s->effect_param << 4);
        }
        RESET_VOLUME_OFFSET(ch);
        xm_param_slide(&ch->volume, ch->fine_volume_slide_up_param, MAX_VOLUME);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_FINE_VOLUME_SLIDE_DOWN)
    case EFFECT_FINE_VOLUME_SLIDE_DOWN:
        if(s->effect_param) {
            ch->fine_volume_slide_down_param = s->effect_param;
        }
        RESET_VOLUME_OFFSET(ch);
        xm_param_slide(&ch->volume, ch->fine_volume_slide_down_param, MAX_VOLUME);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_VOLUME_SLIDE)
    case EFFECT_S3M_VOLUME_SLIDE:
        if(ch->effect_param >> 4 == 0xF
           || (ch->effect_param & 0xF) == 0xF
           || FAST_S3M_VOLUME_SLIDES(&ctx->module)) {
            xm_volume_slide_s3m(ch);
        }
        break;
    #endif

    #if HAS_PANNING && HAS_EFFECT(EFFECT_SET_PANNING)
    case EFFECT_SET_PANNING:
        ch->panning = s->effect_param;
        break;
    #endif

    #if HAS_PANNING && HAS_EFFECT(EFFECT_SET_CHANNEL_PANNING)
    case EFFECT_SET_CHANNEL_PANNING:
        ch->base_panning = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_JUMP_TO_ORDER)
    case EFFECT_JUMP_TO_ORDER:
        ctx->position_jump = true;
        ctx->jump_dest = s->effect_param;
        ctx->jump_row = 0;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_PATTERN_BREAK)
    case EFFECT_PATTERN_BREAK:
        /* Jump after playing this line */
        ctx->pattern_break = true;
        ctx->jump_row = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_SET_TEMPO)
    case EFFECT_SET_TEMPO:
        ctx->current_tempo = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_SET_BPM)
    case EFFECT_SET_BPM:
        ctx->current_bpm = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_SET_GLOBAL_VOLUME)
    case EFFECT_SET_GLOBAL_VOLUME:
        /* xx > MAX_VOLUME is already clamped in load.c */
        ctx->global_volume = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_SET_ENVELOPE_POSITION) \
        && (HAS_FEATURE(FEATURE_VOLUME_ENVELOPES) \
            || (HAS_PANNING && HAS_FEATURE(FEATURE_PANNING_ENVELOPES)))
    case EFFECT_SET_ENVELOPE_POSITION:
        #if HAS_FEATURE(FEATURE_VOLUME_ENVELOPES)
        ch->volume_envelope_frame_count = s->effect_param;
        #endif
        #if HAS_PANNING && HAS_FEATURE(FEATURE_PANNING_ENVELOPES)
        ch->panning_envelope_frame_count = s->effect_param;
        #endif
        break;
    #endif

    #if HAS_EFFECT(EFFECT_MULTI_RETRIG_NOTE)
    case EFFECT_MULTI_RETRIG_NOTE:
        UPDATE_EFFECT_MEMORY_XY(&ch->multi_retrig_param,
                                ch->current->effect_param);
        xm_multi_retrig_note(ctx, ch, ch->multi_retrig_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_MULTI_RETRIG_NOTE)
    case EFFECT_S3M_MULTI_RETRIG_NOTE:
        xm_multi_retrig_note(ctx, ch, ch->effect_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_TREMOR)
    case EFFECT_S3M_TREMOR:
        /* XXX: test S3M tremor on tick 0 */
        xm_tremor(ch, ch->effect_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_EXTRA_FINE_PORTAMENTO_UP)
    case EFFECT_EXTRA_FINE_PORTAMENTO_UP:
        if(s->effect_param & 0x0F) {
            ch->extra_fine_portamento_up_param = s->effect_param;
        }
        xm_pitch_slide(ch, -ch->extra_fine_portamento_up_param, PITCH_SLIDE_CLAMP);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_EXTRA_FINE_PORTAMENTO_DOWN)
    case EFFECT_EXTRA_FINE_PORTAMENTO_DOWN:
        if(s->effect_param) {
            ch->extra_fine_portamento_down_param = s->effect_param;
        }
        xm_pitch_slide(ch, ch->extra_fine_portamento_down_param, PITCH_SLIDE_WRAPAROUND);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_FINE_PORTAMENTO_UP)
    case EFFECT_FINE_PORTAMENTO_UP:
        if(s->effect_param) {
            ch->fine_portamento_up_param = 4 * s->effect_param;
        }
        xm_pitch_slide(ch, -ch->fine_portamento_up_param, PITCH_SLIDE_CLAMP);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_FINE_PORTAMENTO_DOWN)
    case EFFECT_FINE_PORTAMENTO_DOWN:
        if(s->effect_param) {
            ch->fine_portamento_down_param = 4 * s->effect_param;
        }
        xm_pitch_slide(ch, ch->fine_portamento_down_param, PITCH_SLIDE_WRAPAROUND);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_PORTAMENTO_UP)
    case EFFECT_S3M_PORTAMENTO_UP:
        switch(ch->effect_param >> 4) {
        case 0xE:
            /* Extra fine */
            xm_pitch_slide(ch, -(ch->effect_param & 0xF), PITCH_SLIDE_CUT);
            break;
        case 0xF:
            /* Fine */
            xm_pitch_slide(ch, -(ch->effect_param & 0xF) * 4, PITCH_SLIDE_CUT);
            break;
        }
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_PORTAMENTO_DOWN)
    case EFFECT_S3M_PORTAMENTO_DOWN:
        switch(ch->effect_param >> 4) {
        case 0xE:
            /* Extra fine */
            xm_pitch_slide(ch, ch->effect_param & 0xF, PITCH_SLIDE_CUT);
            break;
        case 0xF:
            /* Fine */
            xm_pitch_slide(ch, (ch->effect_param & 0xF) * 4, PITCH_SLIDE_CUT);
            break;
        }
        break;
    #endif

    #if HAS_EFFECT(EFFECT_SET_GLISSANDO_CONTROL)
    case EFFECT_SET_GLISSANDO_CONTROL:
        ch->glissando_control_param = s->effect_param;
        break;
    #endif

    #if HAS_VIBRATO && HAS_EFFECT(EFFECT_SET_VIBRATO_CONTROL)
    case EFFECT_SET_VIBRATO_CONTROL:
        ch->vibrato_control_param = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_TREMOLO) && HAS_EFFECT(EFFECT_SET_TREMOLO_CONTROL)
    case EFFECT_SET_TREMOLO_CONTROL:
        ch->tremolo_control_param = s->effect_param;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_ROW_LOOP)
    case EFFECT_ROW_LOOP:
        ch->pattern_loop_origin = ctx->current_row;
        goto do_pattern_loop;
    #endif

    #if HAS_EFFECT(EFFECT_PATTERN_LOOP)
    case EFFECT_PATTERN_LOOP:
        if(s->effect_param) {
            goto do_pattern_loop;
        } else {
            /* Set loop start point */
            ch->pattern_loop_origin = ctx->current_row;
            /* Replicate FT2 E60 bug */
            ctx->jump_row = ch->pattern_loop_origin;
        }
        break;
    #endif

    #if HAS_LOOPS
    do_pattern_loop:
        if(s->effect_param == ch->pattern_loop_count) {
            /* Loop is over */
            ch->pattern_loop_count = 0;
            break;
        }
        /* Arm the loop */
        ch->pattern_loop_count++;
        ctx->position_jump = true;
        ctx->jump_row = ch->pattern_loop_origin;
        assert(ctx->current_table_index <= UINT8_MAX);
        ctx->jump_dest = (uint8_t)ctx->current_table_index;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_DELAY_PATTERN)
    case EFFECT_DELAY_PATTERN:
        /* Loop current row y times. Tick effects *are* applied
           on tick 0 of repeated rows. */
        ctx->extra_rows = ch->current->effect_param;
        break;
    #endif

    }
}

static void xm_trigger_instrument(xm_context_t* ctx,
                                  xm_channel_context_t* ch) {
    #if HAS_SUSTAIN
    ch->sustained = true;
    #endif

    #if HAS_FEATURE(FEATURE_VOLUME_ENVELOPES)
    ch->volume_envelope_frame_count = 0;
    #endif

    #if HAS_PANNING && HAS_FEATURE(FEATURE_PANNING_ENVELOPES)
    ch->panning_envelope_frame_count = 0;
    #endif

    #if HAS_EFFECT(EFFECT_MULTI_RETRIG_NOTE)
    ch->multi_retrig_ticks = 0;
    #endif

    #if HAS_EFFECT(EFFECT_TREMOR)
    ch->tremor_ticks = 0;
    #endif

    #if HAS_FEATURE(FEATURE_AUTOVIBRATO)
    ch->autovibrato_ticks = 0;
    #endif

    RESET_VOLUME_OFFSET(ch);

    #if HAS_VIBRATO
    if(!HAS_FEATURE(FEATURE_WAVEFORM_CONTINUE)
       || !(VIBRATO_CONTROL_PARAM(ch) & 128)) {
        ch->vibrato_ticks = 0;
    }
    #endif

    #if HAS_EFFECT(EFFECT_TREMOLO)
    if(!HAS_FEATURE(FEATURE_WAVEFORM_CONTINUE)
       || !(TREMOLO_CONTROL_PARAM(ch) & 128)) {
        ch->tremolo_ticks = 0;
    }
    #endif

    #if XM_TIMING_FUNCTIONS
    ch->latest_trigger = ctx->generated_samples;
    if(ch->instrument) {
        ch->instrument->latest_trigger = ctx->generated_samples;
    }
    #endif
}

static void xm_trigger_note(xm_context_t* ctx, xm_channel_context_t* ch) {
    xm_sample_t* new_sample;
    int16_t note;

    #if XM_RAMPING
    uint8_t i;

    if(ch->sample && ch->period) {
        _XM_STATIC_ASSERT_FUNCTION(RAMPING_POINTS <= UINT8_MAX,"");
        for(i = 0; i < RAMPING_POINTS; ++i) {
            ch->end_of_previous_sample[i] = xm_next_of_sample(ctx, ch);
        }
    } else {
        memset(ch->end_of_previous_sample, 0, RAMPING_POINTS * sizeof(float));
    }
    ch->frame_count = 0;
    #endif

    /* Update ch->sample and ch->instrument */

    #if HAS_FEATURE(FEATURE_INVALID_INSTRUMENTS)
    if(ch->next_instrument == 0 || ch->next_instrument > NUM_INSTRUMENTS(&ctx->module)) {
        #if HAS_INSTRUMENTS
        ch->instrument = NULL;
        #endif
        ch->sample = NULL;
        xm_cut_note(ch);
        return;
    }
    #endif

    #if HAS_INSTRUMENTS
    ch->instrument = ctx->instruments + ch->next_instrument - 1;
    #endif


    #if HAS_FEATURE(FEATURE_MULTISAMPLE_INSTRUMENTS)
    new_sample = ctx->samples
        + ch->instrument->sample_of_notes[ch->orig_note - 1];
    #else
    new_sample = ctx->samples + ch->next_instrument - 1;
    #endif

    #if HAS_FEATURE(FEATURE_INVALID_SAMPLES) && HAS_FEATURE(FEATURE_MULTISAMPLE_INSTRUMENTS)
    if(ch->instrument->sample_of_notes[ch->orig_note - 1] >= ctx->module.num_samples) {
        #if HAS_INSTRUMENTS
        ch->instrument = NULL;
        #endif
        ch->sample = NULL;
        xm_cut_note(ch);
        return;
    }
    #endif

    note = (int16_t)(ch->orig_note + RELATIVE_NOTE(new_sample));
    #if HAS_FEATURE(FEATURE_INVALID_NOTES)
    if(note <= 0 || note >= 120) {
        /* Invalid notes seem to be completely ignored in FT2 */
        return;
    }
    #endif

    ch->sample = new_sample;

    #if HAS_FEATURE(FEATURE_NOTE_SWITCH)
    if(ch->current->note == NOTE_SWITCH) {
        return;
    }
    #endif

    #if HAS_FINETUNES
    /* Handle E5y: Set note fine-tune here; this effect only works in tandem
       with a note and overrides the finetune value stored in the sample. If
       we have Mx in the volume column, it does nothing. */
    if(HAS_EFFECT(EFFECT_SET_FINETUNE) && ch->current->effect_type == EFFECT_SET_FINETUNE) {
        ch->finetune = (int8_t)(ch->current->effect_param * 2 - 16);
    } else {
        ch->finetune = FINETUNE(ch->sample);
    }
    #endif

    ch->period = xm_period(ctx, (int16_t)(16 * (note - 1) + FINETUNE(ch)));

    /* Handle 9xx: Sample offset here, since it does nothing outside of a
       note trigger (ie, called on its own without a note). If we have Mx in
       the volume column, it does nothing. */
    #if HAS_EFFECT(EFFECT_SET_SAMPLE_OFFSET)
    if(ch->current->effect_type == EFFECT_SET_SAMPLE_OFFSET) {
        if(ch->current->effect_param > 0) {
            ch->sample_offset_param = ch->current->effect_param;
        }
        ch->sample_position = ch->sample_offset_param * 256 * SAMPLE_MICROSTEPS;

        #if HAS_SAMPLE_OFFSET_INVALID
        /* An invalid 9xx will *not* clear ch->sample, and if we have an
           instrument trigger, ch->volume and ch->panning will still be
           set; this can affect later ghost notes */
        ch->sample_offset_invalid = ch->sample_position >= ch->sample->length * SAMPLE_MICROSTEPS;
        #endif
    } else {
        ch->sample_position = 0;
        #if HAS_SAMPLE_OFFSET_INVALID
        ch->sample_offset_invalid = false;
        #endif
    }
    #else
        ch->sample_position = 0;
        #if HAS_SAMPLE_OFFSET_INVALID
        ch->sample_offset_invalid = false;
        #endif
    #endif

    #if HAS_GLISSANDO_CONTROL
    ch->glissando_control_error = 0;
    #endif

    #if HAS_VIBRATO
    ch->vibrato_offset = 0;
    #endif

    /* XXX: is this reset by a note trigger or inst trigger? does it matter
       since tremor_on touches volume_offest anyway, and it gets reset by an
       inst trigger?*/
    /* ch->tremor_on = false; */

    #if XM_TIMING_FUNCTIONS
    ch->latest_trigger = ctx->generated_samples;
    ch->sample->latest_trigger = ctx->generated_samples;
    #endif
}

static void xm_cut_note(xm_channel_context_t* ch) {
    /* NB: this is not the same as Key Off */
    ch->volume = 0;
}

static void xm_key_off(xm_channel_context_t* ch) {
    /* Key Off */
    #if HAS_SUSTAIN
    ch->sustained = false;
    #endif

    /* If no volume envelope is used, also cut the note */
    #if HAS_FEATURE(FEATURE_VOLUME_ENVELOPES)
    if(ch->instrument == NULL || ch->instrument->volume_envelope.num_points == 0) {
        xm_cut_note(ch);
    }
    #else
    xm_cut_note(ch);
    #endif
}

static void xm_row(xm_context_t* ctx) {
    xm_pattern_t* cur;
    xm_pattern_slot_t* s;
    xm_channel_context_t* ch;
    bool in_a_loop = false;
    uint8_t i;

    if(POSITION_JUMP(ctx) || PATTERN_BREAK(ctx)) {
        #if HAS_POSITION_JUMP
        if(POSITION_JUMP(ctx)) {
            ctx->current_table_index = ctx->jump_dest;
        } else
        #endif
        {
            ctx->current_table_index++;
            MAYBE_RESTART_POT(ctx);
        }

        #if HAS_EFFECT(EFFECT_PATTERN_BREAK)
        ctx->pattern_break = false;
        #endif

        #if HAS_POSITION_JUMP
        ctx->position_jump = false;
        #endif

        #if HAS_JUMP_ROW
        ctx->current_row = ctx->jump_row;
        ctx->jump_row = 0;
        #endif
    }

    cur = ctx->patterns + ctx->module.pattern_table[ctx->current_table_index];
    s = ctx->pattern_slots + NUM_CHANNELS(&ctx->module) * (cur->rows_index + ctx->current_row);
    ch = ctx->channels;

    /* Read notes� */
    for(i = 0; i < NUM_CHANNELS(&ctx->module); ++i, ++ch, ++s) {
        ch->current = s;

        if(!HAS_EFFECT(EFFECT_DELAY_NOTE) || s->effect_type != EFFECT_DELAY_NOTE) {
            xm_handle_pattern_slot(ctx, ch);
        }

        #if HAS_EFFECT(EFFECT_PATTERN_LOOP)
        if(ch->pattern_loop_count > 0) {
            in_a_loop = true;
        }
        #endif

        #if HAS_ARPEGGIO_RESET
        if(ch->should_reset_arpeggio) {
            /* Reset glissando control error */
            xm_pitch_slide(ch, 0, 0);
            ch->should_reset_arpeggio = false;
            ch->arp_note_offset = 0;
        }
        #elif HAS_EFFECT(EFFECT_ARPEGGIO)
        ch->arp_note_offset = 0;
        #endif

        #if HAS_VIBRATO
        if(SHOULD_RESET_VIBRATO(ch) && !xm_slot_has_vibrato(ch->current)) {
            ch->vibrato_offset = 0;
        }
        #endif
    }

    if(!in_a_loop) {
        /* No E6y loop is in effect (or we are in the first pass) */
        #if XM_LOOPING_TYPE == 2
        ctx->loop_count = ctx->row_loop_count[ctx->current_table_index * MAX_ROWS_PER_PATTERN + ctx->current_row]++;
        #endif
    }

    ctx->current_row++; /* Since this is an uint8, this line can
                         * increment from 255 to 0, in which case it
                         * is still necessary to go the next
                         * pattern. */
    if(!POSITION_JUMP(ctx) && !PATTERN_BREAK(ctx) &&
       (ctx->current_row >= cur->num_rows || ctx->current_row == 0)) {
        #if HAS_JUMP_ROW
        /* This will be 0 most of the time, except when E60 is used */
        ctx->current_row = ctx->jump_row;
        ctx->jump_row = 0;
        #else
        ctx->current_row = 0;
        #endif

        ctx->current_table_index++;
        MAYBE_RESTART_POT(ctx);
    }
}

static uint8_t xm_envelope_lerp(const xm_envelope_point_t* RESTRICT a,
                                const xm_envelope_point_t* RESTRICT b,
                                uint16_t pos) {
    uint32_t val;

    /* Linear interpolation between two envelope points */
    assert(pos >= a->frame);
    assert(a->frame < b->frame);
    _XM_STATIC_ASSERT_FUNCTION(MAX_ENVELOPE_VALUE <= UINT8_MAX,"");
    if(pos >= b->frame) return b->value;
    val = (uint32_t)
        (b->value * (uint16_t)(pos - a->frame)
         + a->value * (uint16_t)(b->frame - pos));
    val /= (uint16_t)(b->frame - a->frame);
    return (uint8_t)val;
}

static uint8_t xm_tick_envelope(xm_channel_context_t* ch,
                                const xm_envelope_t* env,
                                uint16_t* counter) {
    uint8_t j;
    assert(env->num_points >= 2);
    assert(env->loop_start_point < env->num_points);
    assert(env->loop_end_point < env->num_points);

    /* Only loop if we are exactly at loop_end. Don't loop if we went past
       it, with eg a Lxx effect. Don't loop if sustain_point == loop_end and
       the note is not sustained (FT2 quirk). */
    if(*counter == env->points[env->loop_end_point].frame
       && (SUSTAINED(ch) || env->sustain_point != env->loop_end_point)) {
        *counter = env->points[env->loop_start_point].frame;
    }

    /* Don't advance envelope position if we are sustaining */
    if((SUSTAINED(ch) & !(env->sustain_point & 128))
       && *counter == env->points[env->sustain_point].frame) {
        return env->points[env->sustain_point].value;
    }

    /* Find points left and right of current envelope position */
    for(j = env->num_points - 1; j > 0; --j) {
        if(*counter < env->points[j-1].frame) continue;
        return xm_envelope_lerp(env->points + j - 1, env->points + j, (*counter)++);
    }
    
    assert(0);
}

static void xm_tick_envelopes(xm_channel_context_t* ch) {
    xm_instrument_t* inst = INSTRUMENT(ch);
    if(inst == NULL) return;

    #if HAS_FEATURE(FEATURE_AUTOVIBRATO)
    xm_autovibrato(ch);
    #endif

    #if HAS_FADEOUT_VOLUME
    if(!SUSTAINED(ch)) {
        ch->fadeout_volume =
            (ch->fadeout_volume < inst->volume_fadeout) ?
            0 : ch->fadeout_volume - inst->volume_fadeout;
    } else {
        ch->fadeout_volume = MAX_FADEOUT_VOLUME-1;
    }
    #endif

    #if HAS_FEATURE(FEATURE_VOLUME_ENVELOPES)
    ch->volume_envelope_volume =
        inst->volume_envelope.num_points
        ? xm_tick_envelope(ch, &(inst->volume_envelope),
                           &(ch->volume_envelope_frame_count))
        : MAX_ENVELOPE_VALUE;
    #endif

    #if HAS_PANNING && HAS_FEATURE(FEATURE_PANNING_ENVELOPES)
    ch->panning_envelope_panning =
        inst->panning_envelope.num_points
        ? xm_tick_envelope(ch, &(inst->panning_envelope),
                           &(ch->panning_envelope_frame_count))
        : MAX_ENVELOPE_VALUE / 2;
    #endif
}

void xm_tick(xm_context_t* ctx) {
    uint8_t i;
    
    uint32_t samples_in_tick;


    #if HAS_EFFECT(EFFECT_DELAY_PATTERN)
    if(ctx->current_tick >= CURRENT_TEMPO(ctx)) {
        ctx->current_tick = 0;
        ctx->extra_rows_done++;
    }

    /* Are we in the first tick of a new row? (Ie, not tick 0 of a repeated
       row with EDy) */
    if(ctx->current_tick == 0 && (!ctx->extra_rows || ctx->extra_rows_done > ctx->extra_rows)) {
        ctx->extra_rows = 0;
        ctx->extra_rows_done = 0;
        xm_row(ctx);
    }
    #else
    if(ctx->current_tick == 0 || ctx->current_tick >= CURRENT_TEMPO(ctx)) {
        ctx->current_tick = 0;
        xm_row(ctx);
    }
    #endif

    for(i = 0; i < NUM_CHANNELS(&ctx->module); ++i) {
        int32_t base;

        float* out;
        float volume;

        #if HAS_PANNING
        uint8_t panning;
        #endif

        xm_channel_context_t* ch = ctx->channels + i;



        xm_tick_envelopes(ch);

        if(ctx->current_tick || EXTRA_ROWS_DONE(ctx)) {
            xm_tick_effects(ctx, ch);
        }

        if(!ch->period) continue;

        /* Don't truncate, actually round up or down, precision matters
           here (rounding lets us use 0.5 instead of 1 in the error
           formula, see SAMPLE_MICROSTEPS comment) */
        ch->step = (uint32_t) (((uint64_t)xm_frequency(ctx, ch) * SAMPLE_MICROSTEPS + CURRENT_SAMPLE_RATE(ctx) / 2)/ CURRENT_SAMPLE_RATE(ctx));

        assert(ch->volume <= MAX_VOLUME);
        assert(VOLUME_OFFSET(ch) >= -MAX_VOLUME && VOLUME_OFFSET(ch) <= MAX_VOLUME);

        _XM_STATIC_ASSERT_FUNCTION(MAX_VOLUME == 1<<6,"");
        _XM_STATIC_ASSERT_FUNCTION(MAX_ENVELOPE_VALUE == 1<<6,"");
        _XM_STATIC_ASSERT_FUNCTION(MAX_FADEOUT_VOLUME == 1<<15,"");

        /* 6 + 6 + 15 - 2 + 6 => 31 bits of range */
        base = ch->volume - VOLUME_OFFSET(ch);
        #if HAS_VOLUME_OFFSET
        if(base < 0) base = 0;
        else if(base > MAX_VOLUME) base = MAX_VOLUME;
        #endif

        base *= VOLUME_ENVELOPE_VOLUME(ch);
        base *= FADEOUT_VOLUME(ch);
        base /= 4;
        base *= CURRENT_GLOBAL_VOLUME(ctx);
        volume =  (float)base / (float)(INT32_MAX);
        assert(volume >= 0.f && volume <= 1.f);

        #if XM_RAMPING
        out = ch->target_volume;
        #else
        out = ch->actual_volume;
        #endif

        #if HAS_PANNING
        /* Default XM panning (full stereo) */
        panning = ch->panning;
        panning += (uint8_t)
            ((BASE_PANNING(ctx, i) - MAX_PANNING/2)
            * (MAX_PANNING/2
               - abs(ch->panning - MAX_PANNING/2))
            / (MAX_PANNING/2));
        panning += (uint8_t)
            ((PANNING_ENVELOPE_PANNING(ch)
               - MAX_ENVELOPE_VALUE/2)
            * (MAX_PANNING/2
               - abs(panning - MAX_PANNING/2))
            / (MAX_ENVELOPE_VALUE/2));

        /* See https://modarchive.org/forums/index.php?topic=3517.0
         * and https://github.com/Artefact2/libxm/pull/16 */
        out[0] = volume * sqrtf((float)(MAX_PANNING - panning)
                                / (float)MAX_PANNING);
        out[1] = volume * sqrtf((float)panning
                                / (float)MAX_PANNING);

        #elif XM_PANNING_TYPE >= 1 && XM_PANNING_TYPE <= 7
        /* Hard Amiga panning (LRRL) */
        memset(out, 0, 2 * sizeof(float));
        out[((i >> 1) ^ i) & 1] = volume;
        #elif XM_PANNING_TYPE == 9
        /* Scream Tracker 3 default panning (3/C/3/C/...) */
        out[0] = out[1] = volume * .447265625f;
        out[i & 1] *= 2.f;
        #elif XM_PANNING_TYPE == 0
        /* Mono */
        out[0] = out[1] = volume * 0.70703125f;
        #else
        _XM_STATIC_ASSERT_FUNCTION(0, "");
        #endif
    }

    ctx->current_tick++;

    /* FT2 manual says number of ticks / second = BPM * 0.4 */
    _XM_STATIC_ASSERT_FUNCTION(sizeof(ctx->remaining_samples_in_tick) == sizeof(uint32_t), "");
    _XM_STATIC_ASSERT_FUNCTION(sizeof((CURRENT_SAMPLE_RATE(ctx))) == sizeof(uint16_t), "");
    _XM_STATIC_ASSERT_FUNCTION(TICK_SUBSAMPLES % 4 == 0,"");
    _XM_STATIC_ASSERT_FUNCTION(10 * (TICK_SUBSAMPLES / 4) * UINT16_MAX <= UINT32_MAX,"");
    samples_in_tick = CURRENT_SAMPLE_RATE(ctx);
    samples_in_tick *= 10 * TICK_SUBSAMPLES / 4;
    samples_in_tick /= CURRENT_BPM(ctx);
    ctx->remaining_samples_in_tick += samples_in_tick;
}

/* These effects only do something every tick after the first tick of every row.
   Immediate effects (like Cxx or Fxx) are handled in
   xm_handle_pattern_slot(). */
static void xm_tick_effects(xm_context_t* ctx, xm_channel_context_t* ch) {
    #if HAS_VOLUME_COLUMN
    switch(VOLUME_COLUMN(ch->current) >> 4) {

    #if HAS_VOLUME_EFFECT(VOLUME_EFFECT_SLIDE_DOWN)
    case VOLUME_EFFECT_SLIDE_DOWN:
        RESET_VOLUME_OFFSET(ch);
        xm_param_slide(&ch->volume, VOLUME_COLUMN(ch->current) & 0x0F, MAX_VOLUME);
        break;
    #endif

    #if HAS_VOLUME_EFFECT(VOLUME_EFFECT_SLIDE_UP)
    case VOLUME_EFFECT_SLIDE_UP:
        RESET_VOLUME_OFFSET(ch);
        xm_param_slide(&ch->volume, (uint8_t)(VOLUME_COLUMN(ch->current) << 4), MAX_VOLUME);
        break;
    #endif

    #if HAS_VOLUME_EFFECT(VOLUME_EFFECT_VIBRATO)
    case VOLUME_EFFECT_VIBRATO:
        UPDATE_EFFECT_MEMORY_XY(&ch->vibrato_param, VOLUME_COLUMN(ch->current) & 0x0F);
        /* This vibrato *does not* reset pitch when the command
           is discontinued */
        #if HAS_VIBRATO_RESET
        ch->should_reset_vibrato = false;
        #endif
        xm_vibrato(ch);
        break;
    #endif

    #if HAS_PANNING && HAS_VOLUME_EFFECT(VOLUME_EFFECT_PANNING_SLIDE_LEFT)
    case VOLUME_EFFECT_PANNING_SLIDE_LEFT:
        xm_param_slide(&ch->panning, VOLUME_COLUMN(ch->current) & 0x0F, MAX_PANNING-1);
        break;
    #endif

    #if HAS_PANNING && HAS_VOLUME_EFFECT(VOLUME_EFFECT_PANNING_SLIDE_RIGHT)
    case VOLUME_EFFECT_PANNING_SLIDE_RIGHT:
        xm_param_slide(&ch->panning, (uint8_t)(VOLUME_COLUMN(ch->current) << 4), MAX_PANNING-1);
        break;
    #endif

    #if HAS_VOLUME_EFFECT(VOLUME_EFFECT_TONE_PORTAMENTO)
    case VOLUME_EFFECT_TONE_PORTAMENTO:
        xm_tone_portamento(ctx, ch);
        break;
    #endif

    }
    #endif

    switch(ch->current->effect_type) {

    #if HAS_EFFECT(EFFECT_ARPEGGIO)
    case EFFECT_ARPEGGIO:
        if(ch->current->effect_param == 0) break;
        xm_arpeggio(ctx, ch, ch->current->effect_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_ARPEGGIO)
    case EFFECT_S3M_ARPEGGIO:
        xm_arpeggio(ctx, ch, ch->effect_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_PORTAMENTO_UP)
    case EFFECT_PORTAMENTO_UP:
        if(ch->current->effect_param > 0) {
            ch->portamento_up_param = ch->current->effect_param;
        }
        xm_pitch_slide(ch, -4 * ch->portamento_up_param, PITCH_SLIDE_CLAMP);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_PORTAMENTO_UP)
    case EFFECT_S3M_PORTAMENTO_UP:
        if(ch->effect_param < 0xE0) {
            xm_pitch_slide(ch, -4 * ch->effect_param, PITCH_SLIDE_CUT);
        }
        break;
    #endif

    #if HAS_EFFECT(EFFECT_PORTAMENTO_DOWN)
    case EFFECT_PORTAMENTO_DOWN:
        if(ch->current->effect_param > 0) {
            ch->portamento_down_param = ch->current->effect_param;
        }
        xm_pitch_slide(ch, 4 * ch->portamento_down_param, PITCH_SLIDE_WRAPAROUND);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_PORTAMENTO_DOWN)
    case EFFECT_S3M_PORTAMENTO_DOWN:
        if(ch->effect_param < 0xE0) {
            xm_pitch_slide(ch, 4 * ch->effect_param, PITCH_SLIDE_CUT);
        }
        break;
    #endif

    /* XXX: is there a better way to do this? */
    #if HAS_EFFECT(EFFECT_TONE_PORTAMENTO) && HAS_EFFECT(EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE)
    case EFFECT_TONE_PORTAMENTO:
        ;
    case EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE:
        xm_tone_portamento(ctx, ch);
        if(ch->current->effect_type == EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE) {
            goto volume_slide;
        } else {
            break;
        }
    #elif HAS_EFFECT(EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE)
    case EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE:
        #if HAS_TONE_PORTAMENTO
        xm_tone_portamento(ctx, ch);
        #endif
        goto volume_slide;
    #elif HAS_EFFECT(EFFECT_TONE_PORTAMENTO)
    case EFFECT_TONE_PORTAMENTO:
        xm_tone_portamento(ctx, ch);
        break;
    #endif

    #if (HAS_EFFECT(EFFECT_VIBRATO) || HAS_EFFECT(EFFECT_FINE_VIBRATO)) && HAS_EFFECT(EFFECT_VIBRATO_VOLUME_SLIDE)
    #if HAS_EFFECT(EFFECT_VIBRATO)
    case EFFECT_VIBRATO:
    #endif
    #if HAS_EFFECT(EFFECT_FINE_VIBRATO)
    case EFFECT_FINE_VIBRATO:
    #endif
        UPDATE_EFFECT_MEMORY_XY(&ch->vibrato_param, ch->current->effect_param);
        ;
    case EFFECT_VIBRATO_VOLUME_SLIDE:
        #if HAS_VIBRATO_RESET
        ch->should_reset_vibrato = true;
        #endif
        xm_vibrato(ch);
        if(ch->current->effect_type == EFFECT_VIBRATO_VOLUME_SLIDE) {
            goto volume_slide;
        } else {
            break;
        }
    #elif HAS_EFFECT(EFFECT_VIBRATO_VOLUME_SLIDE)
    case EFFECT_VIBRATO_VOLUME_SLIDE:
        #if HAS_VIBRATO
        #if HAS_VIBRATO_RESET
        ch->should_reset_vibrato = true;
        #endif
        xm_vibrato(ch);
        #endif
        goto volume_slide;
    #elif HAS_EFFECT(EFFECT_VIBRATO) || HAS_EFFECT(EFFECT_FINE_VIBRATO)
    #if HAS_EFFECT(EFFECT_VIBRATO)
    case EFFECT_VIBRATO:
    #endif
    #if HAS_EFFECT(EFFECT_FINE_VIBRATO)
    case EFFECT_FINE_VIBRATO:
    #endif
        UPDATE_EFFECT_MEMORY_XY(&ch->vibrato_param, ch->current->effect_param);
        #if HAS_VIBRATO_RESET
        ch->should_reset_vibrato = true;
        #endif
        xm_vibrato(ch);
        break;
    #endif

    #if HAS_VOLUME_SLIDE
    #if HAS_EFFECT(EFFECT_VIBRATO_VOLUME_SLIDE) || HAS_EFFECT(EFFECT_TONE_PORTAMENTO_VOLUME_SLIDE)
    volume_slide:
    #endif
    #if HAS_EFFECT(EFFECT_VOLUME_SLIDE)
    case EFFECT_VOLUME_SLIDE:
    #endif
        if(ch->current->effect_param > 0) {
            ch->volume_slide_param = ch->current->effect_param;
        }
        RESET_VOLUME_OFFSET(ch);
        xm_param_slide(&ch->volume, ch->volume_slide_param, MAX_VOLUME);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_VOLUME_SLIDE)
    case EFFECT_S3M_VOLUME_SLIDE:
    #endif
    #if HAS_EFFECT(EFFECT_S3M_VIBRATO_VOLUME_SLIDE)
    case EFFECT_S3M_VIBRATO_VOLUME_SLIDE:
    #endif
    #if HAS_EFFECT(EFFECT_S3M_TONE_PORTAMENTO_VOLUME_SLIDE)
    case EFFECT_S3M_TONE_PORTAMENTO_VOLUME_SLIDE:
    #endif
    #if HAS_EFFECT(EFFECT_S3M_VOLUME_SLIDE) \
        || HAS_EFFECT(EFFECT_S3M_VIBRATO_VOLUME_SLIDE) \
        || HAS_EFFECT(EFFECT_S3M_TONE_PORTAMENTO_VOLUME_SLIDE)
        if(ch->effect_param >> 4 == 0
           || (ch->effect_param & 0xF) == 0
           || ((ch->effect_param >> 4) != 0xF
               && (ch->effect_param & 0xF) != 0xF)) {
            #if HAS_EFFECT(EFFECT_S3M_VIBRATO_VOLUME_SLIDE)
            if(ch->current->effect_type
               == EFFECT_S3M_VIBRATO_VOLUME_SLIDE) {
                #if HAS_VIBRATO_RESET
                ch->should_reset_vibrato = true;
                #endif
                xm_vibrato(ch);
            }
            #endif
            #if HAS_EFFECT(EFFECT_S3M_TONE_PORTAMENTO_VOLUME_SLIDE)
            if(ch->current->effect_type
               == EFFECT_S3M_TONE_PORTAMENTO_VOLUME_SLIDE) {
                xm_tone_portamento(ctx, ch);
            }
            #endif
            xm_volume_slide_s3m(ch);
        }
        break;
    #endif

    #if HAS_EFFECT(EFFECT_TREMOLO)
    case EFFECT_TREMOLO:
        UPDATE_EFFECT_MEMORY_XY(&ch->tremolo_param, ch->current->effect_param);
        xm_tremolo(ch, ch->tremolo_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_TREMOLO)
    case EFFECT_S3M_TREMOLO:
        xm_tremolo(ch, ch->effect_param);
        /* S3M tremolo peaks at +32 */
        ch->volume_offset >>= 1;
        break;
    #endif

    #if HAS_EFFECT(EFFECT_GLOBAL_VOLUME_SLIDE)
    case EFFECT_GLOBAL_VOLUME_SLIDE:
        if(ch->current->effect_param > 0) {
            ch->global_volume_slide_param = ch->current->effect_param;
        }
        xm_param_slide(&ctx->global_volume, ch->global_volume_slide_param, MAX_VOLUME);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_KEY_OFF)
    case EFFECT_KEY_OFF:
        if(ctx->current_tick != ch->current->effect_param) break;
        xm_key_off(ch);
        break;
    #endif

    #if HAS_PANNING && HAS_EFFECT(EFFECT_PANNING_SLIDE)
    case EFFECT_PANNING_SLIDE:
        if(ch->current->effect_param > 0) {
            ch->panning_slide_param = ch->current->effect_param;
        }
        xm_param_slide(&ch->panning, ch->panning_slide_param, MAX_PANNING-1);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_MULTI_RETRIG_NOTE)
    case EFFECT_MULTI_RETRIG_NOTE:
        /* Effect memory was already set in tick 0 */
        xm_multi_retrig_note(ctx, ch, ch->multi_retrig_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_MULTI_RETRIG_NOTE)
    case EFFECT_S3M_MULTI_RETRIG_NOTE:
        xm_multi_retrig_note(ctx, ch, ch->effect_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_TREMOR)
    case EFFECT_TREMOR:
        if(ch->current->effect_param > 0) {
            ch->tremor_param = ch->current->effect_param;
        }
        xm_tremor(ch, ch->tremor_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_S3M_TREMOR)
    case EFFECT_S3M_TREMOR:
        xm_tremor(ch, ch->effect_param);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_RETRIGGER_NOTE)
    case EFFECT_RETRIGGER_NOTE:
        assert(ch->current->effect_param > 0);
        if(ctx->current_tick % ch->current->effect_param) break;
        xm_trigger_instrument(ctx, ch);
        xm_trigger_note(ctx, ch);
        xm_tick_envelopes(ch);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_CUT_NOTE)
    case EFFECT_CUT_NOTE:
        if(ctx->current_tick != ch->current->effect_param) break;
        xm_cut_note(ch);
        break;
    #endif

    #if HAS_EFFECT(EFFECT_DELAY_NOTE)
    case EFFECT_DELAY_NOTE:
        if(ctx->current_tick != ch->current->effect_param) {
            break;
        }
        xm_handle_pattern_slot(ctx, ch);
        xm_trigger_instrument(ctx, ch);
        if(!NOTE_IS_KEY_OFF(ch->current->note)) {
            xm_trigger_note(ctx, ch);
        }
        xm_tick_envelopes(ch);
        break;
    #endif

    }
}

static float xm_sample_at(const xm_context_t* ctx, const xm_sample_t* sample, uint32_t k) {
    assert(k < sample->length);
    assert(sample->index + k < ctx->module.samples_data_length);

    return SAMPLE_DATA(ctx, sample->index + k);
}

/* XXX: rename me or merge with xm_next_of_channel */
static float xm_next_of_sample(xm_context_t* ctx, xm_channel_context_t* ch) {
    const xm_sample_t* smp = ch->sample;
    uint32_t a, b;
    float u;
    #if XM_LINEAR_INTERPOLATION
    float t;
    #endif

    assert(smp == NULL || smp->loop_length <= smp->length);

    /* Zero-length samples are also handled here, since loop_length will
       always be zero for these */
    if(SAMPLE_OFFSET_INVALID(ch) || smp == NULL || (smp->loop_length == 0 && ch->sample_position >= smp->length * SAMPLE_MICROSTEPS)) {
        #if XM_RAMPING
        /* Smoothly transition between old sample and silence */
        if(ch->frame_count >= RAMPING_POINTS) return 0.f;
        return XM_LERP(ch->end_of_previous_sample[ch->frame_count], .0f, (float)ch->frame_count / (float)RAMPING_POINTS);
        #else
        return 0.f;
        #endif
    }

    if(smp->loop_length && ch->sample_position >= smp->length * SAMPLE_MICROSTEPS) {
        /* Remove extra loops. For ping-pong logic, the loop length is
           doubled, and the second half is the reverse of the looped
           part. */
        uint32_t off = (uint32_t) ((smp->length - smp->loop_length) * SAMPLE_MICROSTEPS);

        ch->sample_position -= off;
        ch->sample_position %= PING_PONG(smp)
            ? smp->loop_length * SAMPLE_MICROSTEPS * 2
            : smp->loop_length * SAMPLE_MICROSTEPS;
        ch->sample_position += off;
    }

    a = ch->sample_position / SAMPLE_MICROSTEPS;

    #if XM_LINEAR_INTERPOLATION
    t = (float) (ch->sample_position % SAMPLE_MICROSTEPS) / (float)SAMPLE_MICROSTEPS;
    #endif

    /* Find the next sample point (for linear interpolation only) and also
       apply ping-pong logic */
    if(smp->loop_length == 0) {
        b = (a+1 < ch->sample->length) ? (a+1) : a;
    } else if(!PING_PONG(smp)) {
        b = (a+1 == smp->length) ? smp->length - smp->loop_length : (a+1);
    } else {
        if(a < smp->length) {
            /* In the first half of the loop, go forwards */
            b = (a+1 == smp->length) ? a : (a+1);
        } else {
            /* In the second half of the loop, go backwards */
            /* loop_end -> loop_end - 1 */
            /* loop_end + 1 -> loop_end - 2 */
            /* etc. */
            /* loop_end + loop_length - 1 -> loop_start */
            a = smp->length * 2 - 1 - a;
            b = (a == smp->length - smp->loop_length) ? a : (a-1);
            assert(a >= smp->length - smp->loop_length);
            assert(b >= smp->length - smp->loop_length);
        }
    }

    assert(a < smp->length);
    assert(b < smp->length);
    u = xm_sample_at(ctx, smp, a);

    #if XM_LINEAR_INTERPOLATION
    /* u = sample_at(a), v = sample_at(b), t = lerp factor (0..1) */
    u = XM_LERP(u, xm_sample_at(ctx, smp, b), t);
    #endif

    #if XM_RAMPING
    if(ch->frame_count < RAMPING_POINTS) {
        /* Smoothly transition between old and new sample. */
        return XM_LERP(ch->end_of_previous_sample[ch->frame_count], u, (float)ch->frame_count / (float)RAMPING_POINTS);
    }
    #endif

    ch->sample_position += ch->step;
    return u;
}

static void xm_next_of_channel(xm_context_t* ctx, xm_channel_context_t* ch, float* out_left, float* out_right) {
    const float fval = xm_next_of_sample(ctx, ch) * AMPLIFICATION;

    if(CHANNEL_MUTED(ch)
       || (INSTRUMENT(ch) != NULL && INSTRUMENT_MUTED(INSTRUMENT(ch)))
       || (MAX_LOOP_COUNT(&ctx->module) > 0
           && LOOP_COUNT(ctx) >= MAX_LOOP_COUNT(&ctx->module))) {
        return;
    }

    *out_left += fval * ch->actual_volume[0];
    *out_right += fval * ch->actual_volume[1];

    #if XM_RAMPING
    ch->frame_count++;
    XM_SLIDE_TOWARDS(&(ch->actual_volume[0]), ch->target_volume[0], RAMPING_VOLUME_RAMP);
    XM_SLIDE_TOWARDS(&(ch->actual_volume[1]), ch->target_volume[1], RAMPING_VOLUME_RAMP);
    #endif
}

static void xm_sample_unmixed(xm_context_t* ctx, float* out_lr) {
    uint8_t i;

    if(_xm_ckd_sub_u32_uu(&ctx->remaining_samples_in_tick, ctx->remaining_samples_in_tick, TICK_SUBSAMPLES)) {
        xm_tick(ctx);
    }

    for(i = 0; i < NUM_CHANNELS(&ctx->module); ++i, out_lr += 2) {
        out_lr[0] = 0; 
        out_lr[1] = 0;
        xm_next_of_channel(ctx, ctx->channels + i, out_lr, out_lr + 1);

        assert(out_lr[0] <= 1.0);
        assert(out_lr[0] >= -1.0);
        assert(out_lr[1] <= 1.0);
        assert(out_lr[1] >= -1.0);
    }
}

static void xm_sample(xm_context_t* ctx, float* out_left, float* out_right) {
    uint8_t i;
    if(_xm_ckd_sub_u32_uu(&ctx->remaining_samples_in_tick, ctx->remaining_samples_in_tick, TICK_SUBSAMPLES)) {
        xm_tick(ctx);
    }

    for(i = 0; i < NUM_CHANNELS(&ctx->module); ++i) {
        xm_next_of_channel(ctx, ctx->channels + i, out_left, out_right);
    }

    assert(*out_left <= NUM_CHANNELS(&ctx->module));
    assert(*out_left >= -NUM_CHANNELS(&ctx->module));
    assert(*out_right <= NUM_CHANNELS(&ctx->module));
    assert(*out_right >= -NUM_CHANNELS(&ctx->module));
}

void xm_generate_samples(xm_context_t* ctx, float* output, uint16_t numsamples) {
    uint16_t i;

    #if XM_TIMING_FUNCTIONS
    ctx->generated_samples += numsamples;
    #endif

    memset(output, 0, 2 * sizeof(float) * numsamples);

    for(i = 0; i < numsamples; i++, output += 2) {
        xm_sample(ctx, output, output + 1);
    }
}

void xm_generate_samples_noninterleaved(xm_context_t* ctx, float* out_left, float* out_right, uint16_t numsamples) {
    uint16_t i;

    #if XM_TIMING_FUNCTIONS
    ctx->generated_samples += numsamples;
    #endif

    memset(out_left, 0, sizeof(float) * numsamples);
    memset(out_right, 0, sizeof(float) * numsamples);

    for(i = 0; i < numsamples; ++i) {
        xm_sample(ctx, out_left++, out_right++);
    }
}

void xm_generate_samples_unmixed(xm_context_t* ctx, float * out, uint16_t numsamples) {
    uint16_t i;

    #if XM_TIMING_FUNCTIONS
    ctx->generated_samples += numsamples;
    #endif
    for(i = 0; i < numsamples; ++i, out += NUM_CHANNELS(&ctx->module) * 2) {
        xm_sample_unmixed(ctx, out);
    }
}
