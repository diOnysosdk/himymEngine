/* Fork of Artefact2/libxm for Windows 9x and higher              */
/* Fork maintainer: MikeEviscerate <cpe.bach03@proton.me>         */

/* libxm author: Romain "Artefact2" Dalmaso <artefact2@gmail.com> */

/* This program is free software. It comes without any warranty, to the
 * extent permitted by applicable law. You can redistribute it and/or
 * modify it under the terms of the Do What The Fuck You Want To Public
 * License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

#include "xm_internal.h"
#define _XM_FILE_NAME xm_c


uint16_t xm_rand16(uint32_t* state) {
    /* https://arxiv.org/abs/2001.05304 */
    return (uint16_t)(*state = *state * 0xD9F5 + 1);
}

void xm_set_max_loop_count(xm_context_t* context,
                           uint8_t loopcnt) {
    #if XM_LOOPING_TYPE == 2
    context->module.max_loop_count = loopcnt;
    #endif
}

uint8_t xm_get_loop_count(const xm_context_t* context) {
    return LOOP_COUNT(context);
}



void xm_seek(xm_context_t* ctx, uint8_t pot, uint8_t row, uint8_t tick) {
    ctx->current_table_index = pot;
    ctx->current_row = row;
    ctx->current_tick = tick;
    ctx->remaining_samples_in_tick = 0;
}



bool xm_mute_channel(xm_context_t* ctx,
                     uint8_t channel,
                     bool mute) {

    #if XM_MUTING_FUNCTIONS
        bool old;
    #endif

    /* I know this looks dumb. But I am trying to keep behaviour 
       as close as possible to the OG code's     */
    assert(channel <= NUM_CHANNELS(&ctx->module));

    #if XM_MUTING_FUNCTIONS
        old = ctx->channels[channel - 1].muted;
        ctx->channels[channel - 1].muted = mute;
        return old;
    #else
        return false;
    #endif
}

bool xm_mute_instrument(xm_context_t* ctx, uint8_t instr,
                        bool mute) {

    #if XM_MUTING_FUNCTIONS
        bool old;
    #endif

    assert(instr >= 1 && instr <= NUM_INSTRUMENTS(&ctx->module));

    #if XM_MUTING_FUNCTIONS
        old = ctx->instruments[instr - 1].muted;
        ctx->instruments[instr - 1].muted = mute;
        return old;
    #else
        return false;
    #endif
}



#if XM_STRINGS
const char* xm_get_module_name(const xm_context_t* ctx) {
    return ctx->module.name;
}

const char* xm_get_tracker_name(const xm_context_t* ctx) {
    return ctx->module.trackername;
}

const char* xm_get_instrument_name(const xm_context_t* ctx, uint8_t i) {
    assert(i >= 1 && i <= NUM_INSTRUMENTS(&ctx->module));

    #if HAS_INSTRUMENTS
    return ctx->instruments[i-1].name;
    #else
    return "";
    #endif
}

const char* xm_get_sample_name(const xm_context_t* ctx, uint16_t s) {
    assert(s <= ctx->module.num_samples);
    return ctx->samples[s].name;
}
#else
const char* xm_get_module_name(const xm_context_t* ctx) {
    return "";
}

const char* xm_get_tracker_name(const xm_context_t* ctx) {
    return "";
}

const char* xm_get_instrument_name(const xm_context_t* ctx,
                                   uint8_t i) {
    return "";
}

const char* xm_get_sample_name(const xm_context_t* ctx, uint16_t s) {
    return "";
}
#endif



uint8_t xm_get_number_of_channels(const xm_context_t* ctx) {
    return NUM_CHANNELS(&ctx->module);
}

uint16_t xm_get_module_length(const xm_context_t* ctx) {
    return ctx->module.length;
}

uint16_t xm_get_number_of_patterns(const xm_context_t* ctx) {
    return ctx->module.num_patterns;
}

uint16_t xm_get_number_of_rows(const xm_context_t* ctx, uint16_t pattern) {
    return ctx->patterns[pattern].num_rows;
}

uint8_t xm_get_number_of_instruments(const xm_context_t* ctx) {
    return NUM_INSTRUMENTS(&ctx->module);
}

uint16_t xm_get_number_of_samples(const xm_context_t* ctx) {
    return ctx->module.num_samples;
}

xm_sample_point_t* xm_get_sample_waveform(xm_context_t* ctx, uint16_t sample, uint32_t* length) {
    xm_sample_t* s;
    
    assert(sample <= ctx->module.num_samples);
    s = ctx->samples + sample;
    *length = s->length;
    return ctx->samples_data + s->index;
}



void xm_get_playing_speed(const xm_context_t* ctx,
                          uint8_t* bpm, uint8_t* tempo) {
    if(bpm) *bpm = CURRENT_BPM(ctx);
    if(tempo) *tempo = CURRENT_TEMPO(ctx);
}

void xm_get_position(const xm_context_t* ctx, uint8_t* pattern_index,
                     uint8_t* pattern, uint8_t* row, uint32_t* samples) {
    _XM_STATIC_ASSERT_FUNCTION(PATTERN_ORDER_TABLE_LENGTH - 1 <= UINT8_MAX, "");
    if(pattern_index) *pattern_index = (uint8_t)ctx->current_table_index;
    if(pattern) *pattern = ctx->module.pattern_table[ctx->current_table_index];
    if(row) *row = ctx->current_row - 1;
    if(samples) {
        #if XM_TIMING_FUNCTIONS
            *samples = ctx->generated_samples;
        #else
            *samples = 0;
        #endif
    }
}

uint32_t xm_get_latest_trigger_of_instrument(const xm_context_t* ctx, uint8_t instr) {
    assert(instr >= 1 && instr <= NUM_INSTRUMENTS(&ctx->module));

    #if XM_TIMING_FUNCTIONS
    return ctx->instruments[instr-1].latest_trigger;
    #else
    return 0;
    #endif
}

uint32_t xm_get_latest_trigger_of_sample(const xm_context_t* ctx, uint16_t s) {
    assert(s <= ctx->module.num_samples);

    #if XM_TIMING_FUNCTIONS
        return ctx->samples[s].latest_trigger;
    #else
        return 0;
    #endif
}

uint32_t xm_get_latest_trigger_of_channel(const xm_context_t* c, uint8_t chn) {
    assert(chn >= 1 && chn <= NUM_CHANNELS(&c->module));

    #if XM_TIMING_FUNCTIONS
        return c->channels[chn - 1].latest_trigger;
    #else
        return 0;
    #endif
}

bool xm_is_channel_active(const xm_context_t* ctx, uint8_t chn) {
    const xm_channel_context_t* ch = ctx->channels + (chn - 1);

    assert(chn >= 1 && chn <= NUM_CHANNELS(&ctx->module));
    return ch->sample != NULL && (ch->actual_volume[0] + ch->actual_volume[1]) > 0.001f;
}

float xm_get_frequency_of_channel(const xm_context_t* ctx, uint8_t chn) {
    assert(chn >= 1 && chn <= NUM_CHANNELS(&ctx->module));
    return (float)ctx->channels[chn - 1].step * (float)CURRENT_SAMPLE_RATE(ctx) / (float)SAMPLE_MICROSTEPS;
}

float xm_get_volume_of_channel(const xm_context_t* ctx, uint8_t chn) {
    float x;
    float y;
    assert(chn >= 1 && chn <= NUM_CHANNELS(&ctx->module));

    /* Instead of duplicating the panning and volume formulas, just
       reciprocate the panning math from cached computed volumes */
    x = ctx->channels[chn-1].actual_volume[0];
    y = ctx->channels[chn-1].actual_volume[1];
    return sqrtf(x*x + y*y);
}

float xm_get_panning_of_channel(const xm_context_t* ctx, uint8_t chn) {
    float x;
    float y;
    assert(chn >= 1 && chn <= NUM_CHANNELS(&ctx->module));

    x = ctx->channels[chn-1].actual_volume[0];
    x *= x;
    y = ctx->channels[chn-1].actual_volume[1];
    y *= y;
    return (y / (x + y));
}

uint8_t xm_get_instrument_of_channel(const xm_context_t* ctx, uint8_t chn) {
    const xm_channel_context_t* ch = ctx->channels + (chn - 1);

    assert(chn >= 1 && chn <= NUM_CHANNELS(&ctx->module));

    #if HAS_INSTRUMENTS
        if(ch->instrument == NULL) return 0;
        assert(ch->instrument - ctx->instruments < UINT8_MAX);
        return (uint8_t)(1 + (ch->instrument - ctx->instruments));
    #else
        if(ch->sample == NULL) return 0;
        assert(ch->sample - ctx->samples < UINT8_MAX);
        return (uint8_t)(1 + (ch->sample - ctx->samples));
    #endif
}

void xm_reset_context(xm_context_t* ctx) {

    memset(ctx->channels, 0, sizeof(xm_channel_context_t) * NUM_CHANNELS(&ctx->module));

    #if HAS_PANNING && HAS_EFFECT(EFFECT_SET_CHANNEL_PANNING) 
    {
        uint8_t ch;
        for (ch = 0; ch < NUM_CHANNELS(&ctx->module); ++ch) {
            ctx->channels[ch].base_panning = DEFAULT_CHANNEL_PANNING(&ctx->module, ch);
        }
    }
    #endif

    #if XM_LOOPING_TYPE == 2
        memset(ctx->row_loop_count, 0, MAX_ROWS_PER_PATTERN * ctx->module.length);
    #endif

    memset((char*)ctx + offsetof(xm_context_t, remaining_samples_in_tick), 0, sizeof(xm_context_t) - offsetof(xm_context_t, remaining_samples_in_tick));

    #if HAS_GLOBAL_VOLUME
    ctx->global_volume = DEFAULT_GLOBAL_VOLUME(&ctx->module);
    #endif

    #if HAS_EFFECT(EFFECT_SET_TEMPO)
    ctx->current_tempo = DEFAULT_TEMPO(&ctx->module);
    #endif

    #if HAS_EFFECT(EFFECT_SET_BPM)
    ctx->current_bpm = DEFAULT_BPM(&ctx->module);
    #endif

    #if XM_TIMING_FUNCTIONS
    {
        xm_instrument_t* inst = ctx->instruments;
        xm_sample_t* smp = ctx->samples;
        uint16_t i;
        
        for (i = ctx->module.num_instruments; i; --i, ++inst) {
            inst->latest_trigger = 0;
        }

        for (i = ctx->module.num_samples; i; --i, ++smp) {
            smp->latest_trigger = 0;
        }
    }
    #endif
}

void xm_set_sample_rate(xm_context_t* ctx, uint16_t rate) {
    #if XM_SAMPLE_RATE == 0
    ctx->current_sample_rate = rate;
    #endif
}

uint16_t xm_get_sample_rate(const xm_context_t* ctx) {
    return CURRENT_SAMPLE_RATE(ctx);
}

/* For debugging */
void xm_print_pattern(xm_context_t* ctx, uint8_t pat) {
    #if XM_VERBOSE
    uint8_t row;
    uint8_t ch;

    static const char* const notes[] = {
        "C-", "C#", "D-", "D#", "E-", "F-",
        "F#", "G-", "G#", "A-", "A#", "B-" };

    fprintf(stderr, "+-%02X-+", pat);
    for(ch = 0; ch < NUM_CHANNELS(&ctx->module); ++ch) {
        fprintf(stderr, "---- CH %02d -----+", ch + 1);
    }
    fprintf(stderr, "\n");
    for(row = 0; row < 64; ++row) {

        fprintf(stderr, "| %02X | ", row);
        for(ch = 0; ch < NUM_CHANNELS(&ctx->module); ++ch) {
            xm_pattern_slot_t* s = ctx->pattern_slots + (ctx->patterns[pat].rows_index + row) * NUM_CHANNELS(&ctx->module) + ch;

            if(s->note == NOTE_KEY_OFF) {
                fprintf(stderr, "OFF ");
            } else if(s->note == NOTE_SWITCH) {
                fprintf(stderr, "... ");
            } else if(s->note) {
                fprintf(stderr, "%s%u ",
                        notes[(s->note - 1) % 12],
                        (s->note - 1) / 12);
            } else {
                fprintf(stderr, "... ");
            }
            if(s->instrument) {
                fprintf(stderr, "%02X ", s->instrument);
            } else {
                fprintf(stderr, ".. ");
            }
            if(VOLUME_COLUMN(s)) {
                fprintf(stderr, "%02X ", VOLUME_COLUMN(s));
            } else {
                fprintf(stderr, ".. ");
            }
            if(s->effect_type || s->effect_param) {
                fprintf(stderr, "%02X%02X | ", s->effect_type,
                       s->effect_param);
            } else {
                fprintf(stderr, ".... | ");
            }
        }
        fprintf(stderr, "\n");
    }
    fprintf(stderr, "+----+");
    for(ch = 0; ch < NUM_CHANNELS(&ctx->module); ++ch) {
        fprintf(stderr, "----------------+");
    }
    fprintf(stderr, "\n");
    #endif
}


#if XM_VERBOSE
#include <stdarg.h>

void xm_notice(const char* funcName, const char* fmt, ...) {
    va_list args;

    fprintf(stderr, "%s(): ", funcName);
    
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    
    fprintf(stderr, "\n");
    fflush(stderr);
}

void xm_trace(const char* funcName, const xm_context_t* ctx, const char* fmt, ...) {
    va_list args;

    assert(ctx != NULL);
    fprintf(stderr, "%s(): pot %x row %x tick %x: ", funcName, ctx->current_table_index, ctx->current_row, ctx->current_tick);

    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);

    fprintf(stderr, "\n");
    fflush(stderr);
}
#endif

